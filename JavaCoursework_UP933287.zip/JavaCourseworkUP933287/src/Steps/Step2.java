

package Steps;

import Devices.SmartDevice;
import mainClasses.Help;
import mainClasses.SmartHome;

/**
 *
 * @author georg
 */

public class Step2 {

    
    public static void main(String[] args) {
        try{
            //1
            SmartHome sh = Help.createSH();
            Help.output(sh.toString());
            
            //2
            Object[] dvcs = Help.populateArray();
            sh = new SmartHome(dvcs);
            Help.output(sh.toString());
            
            //3
            int index = Help.inputINT("Please enter an index to change: ");
            Object tempDevice = sh.getDevice(index);
            SmartDevice device = SmartDevice.class.cast(tempDevice);
            Help.output(device.toString());
            device.switchOn();
            Help.output(device.toString());
            device.switchOff();
            Help.output(device.toString());
            
            Help.output(sh.toString());
            
            //4
            double location = Help.inputDOUBLE("Please enter a Location to search: ");
            tempDevice = sh.getDevice(location);
            device = SmartDevice.class.cast(tempDevice);
            Help.output(device.toString());
            device.switchOn();
            Help.output(device.toString());
            device.switchOff();
            Help.output(device.toString());
        }
        
        
        
        
        catch(NullPointerException e){
            System.out.print("NullPointerException Caught,\n "
                    + "check the size of the devices array\n");    
        }
        catch(ArrayIndexOutOfBoundsException outOfBounds){
            System.out.print("Incorrect Index!\n"); 
        }
    }
        

}
