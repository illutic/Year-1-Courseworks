
package Steps;

import Devices.SmartFridge;
import mainClasses.Help;
import mainClasses.SmartHome;

/**
 *
 * @author georg
 */

public class Step4 {

    
    public static void main(String[] args) {
        try{
            //1
            SmartHome sh = Help.createSH4();
            Help.output(sh.toString());
            
            //2
            Object[] dvcs = Help.populateArray4();
            sh = new SmartHome(dvcs);
            Help.output(sh.toString());
                        
            //2
            sh.shutdown();
            Help.output(sh.toString());
            //3
            int index = Help.inputINT("Please enter a fridge index to select: ");
            Object tempDevice = sh.getDevice(index);
            if(tempDevice.getClass() == SmartFridge.class){
                SmartFridge device = SmartFridge.class.cast(tempDevice);
                int controller = Help.inputINT("Enter: 1 for Increment | 0 for Decrement: ");
                if (controller == 1){device.increment();}
                else if (controller == 0){device.decrement();}
            }
            Help.output(sh.toString());
        }
        
        
        
        
        catch(NullPointerException e){System.out.print(" No Such Device Found\n");}
        catch(ArrayIndexOutOfBoundsException outOfBounds){
            System.out.print("Incorrect Index!\n"); 
        }
    }

}
