
package Steps;

import Devices.SmartDevice;
import mainClasses.Help;

/**
 *
 * @author georg
 */

public class Step1 {

    
    public static void main(String[] args) {
        try{
            //1
            SmartDevice device = new SmartDevice("DEVICE 1", 1.0, true);
            Help.output(device.toString());
            //2
            Object[] dvcs= Help.populateArray();
            for(Object i : dvcs){
                System.out.print(i.toString());
            }
            
            if(dvcs.length > 0)
            {
                int index = Help.inputINT("\nPlease enter an index to change: ");
                device = SmartDevice.class.cast(dvcs[index]);
                if(device.isSwitchedOn()){device.switchOff();}
                else{device.switchOn();}
                for(Object i : dvcs){
                    System.out.print(i.toString());
                }
            }
        }
        
        
        
        
        catch(NullPointerException e){
            System.out.print(" No Such Device Found\n");    
        }
        catch(ArrayIndexOutOfBoundsException outOfBounds){
            System.out.print("Incorrect Index!\n"); 
        }
    }


}
