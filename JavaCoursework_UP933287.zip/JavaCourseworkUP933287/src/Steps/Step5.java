
package Steps;

import mainClasses.Help;
import mainClasses.SmartHome;

/**
 *
 * @author georg
 */

public class Step5 {
    public static void main(String[] args) {
        try{
            //1
            SmartHome sh = new SmartHome(Help.populateArray5());
            Help.output(sh.toString());
            int index = Help.inputINT("Please enter a Lamp index to select: ");
            
            Object tempDevice = sh.getDevice(index);
            Help.changeMode(tempDevice);
            
            //2 
            sh = new SmartHome(Help.populateArray5());
            Help.output(sh.toString());
            double location = Help.inputDOUBLE("Please enter a Lamp location to select: ");
            
            tempDevice = sh.getDevice(location);
            Help.changeMode(tempDevice);
            
            //3
            sh = new SmartHome(Help.populateArray5());
            Help.output(sh.toString());
            location = Help.inputDOUBLE("Please enter a Lamp location to select: ");
            
            tempDevice = sh.getDevice(location);
            Help.changeMode(tempDevice);
        }
        
        
        
        
        catch(NullPointerException e){System.out.print(" No Such Device Found\n");}
        catch(ArrayIndexOutOfBoundsException outOfBounds){
            System.out.print("Incorrect Index!\n"); 
        }
    }

}
