
package Steps;

import mainClasses.Help;
import mainClasses.SmartHome;

/**
 *
 * @author georg
 */

public class Step3 {

    
    public static void main(String[] args) {
        try{
            //1

            Object[] dvcs = Help.populateArray();
            SmartHome sh = new SmartHome(dvcs);
            Help.output(sh.toString());
            sh.addDevice(Help.deviceInput());
            Help.output(sh.toString());
            
            //2
            int room = Help.inputINT("Please enter room to set: ");
            boolean status = Help.inputBOOL("Please enter status to set: ");
            sh.setAllInRoom(room, status);
            Help.output(sh.toString());
            //3
            sh.shutdown();
            Help.output(sh.toString());
        }
        
        
        
        
        catch(NullPointerException e){
            System.out.print("NullPointerException Caught,\n "
                    + "check the size of the devices array\n");    
        }
        catch(ArrayIndexOutOfBoundsException outOfBounds){
            System.out.print("Incorrect Index!\n"); 
        }
    }
    
    

}
