
package Devices;

/**
 *
 * @author georg
 */
public class SmartDevice {
    private String name;
    private double location;
    private boolean switchedOn;
    
    public SmartDevice(String name, double location, boolean switchedOn){
        this.name = name;
        this.location = location;
        this.switchedOn = switchedOn;
    }
    
    public String getName(){return name;}
    public double getLocation(){return location;}
    public boolean isSwitchedOn(){return switchedOn;}
    
    public void setName(String name){this.name = name;}
    public void setLocation(double location){this.location = location;}
    
    public void switchOn(){
        this.switchedOn = true;
    }
    public void switchOff(){
        this.switchedOn = false;
    }
    

    
    @Override
    public String toString(){
        String str = "----------\n" +
                     "-"+name.toUpperCase()+"-\n" +
                     "----------\n";
        str += "Name:\t\t" + name + "\n";
        str += "Location:\t" + location + "\n";
        str += "Switched On:\t" + switchedOn + "\n";
        str += "----------";
        return str;
    }

}
