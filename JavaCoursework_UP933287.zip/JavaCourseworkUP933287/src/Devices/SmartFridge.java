
package Devices;

/**
 *
 * @author georg
 */
public class SmartFridge extends SmartDevice{
    private double currentTemperature;

    public SmartFridge(String name, double location, double currentTemperature) {
        super(name, location, true);
        this.currentTemperature = currentTemperature;
    }

    public void increment(){currentTemperature +=1;}

    public void decrement(){currentTemperature -=1;}
    @Override
    public void switchOff(){}
    
    public String toString(){
        String str = super.toString() + "\n";
        str += "Current Temperature:\t" + currentTemperature + "\n";
        str += "----------";
        return str;
    }
    
}
