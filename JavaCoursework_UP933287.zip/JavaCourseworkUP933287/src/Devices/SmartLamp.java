/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Devices;

/**
 *
 * @author georg
 */
public class SmartLamp extends SmartDevice{
    private LightModes mode;
    
    public SmartLamp(String name, double location, boolean switchedOn, LightModes mode) {
        super(name, location, switchedOn);
        this.mode = mode;
    }
    
    public void setMode(LightModes mode){this.mode = mode;}
    public LightModes getMode(){return this.mode;}

    public String toString(){
        String str = super.toString() + "\n";
        str += "Mode:\t" + mode + "\n";
        str += "----------";
        return str;
    }
}
