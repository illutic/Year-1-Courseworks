/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Devices;

/**
 *
 * @author georg
 */
public enum LightModes {
    NIGHT("This mode turns the Lamp brightness into a night light, primarily for sleeping"),
    SOFT("This mode turns the Lamp brightness into a room background mode, used for watching television, eating, etc."),
    STANDARD("This mode turns the Lamp brightness into standard brightness, used for reading, doing work, etc. ");
    
    public final String description;
    
    private LightModes(String description){
        this.description = description;
    }
}
