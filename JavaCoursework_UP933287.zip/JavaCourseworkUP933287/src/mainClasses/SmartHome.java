
package mainClasses;

import Devices.SmartDevice;

/**
 *
 * @author georg
 */

public class SmartHome {
    Object[] devices;
    
    //Constructors
    public SmartHome(int size){
        this.devices = new SmartDevice[size];
    }
    public SmartHome(Object[] devices){
        this.devices = devices;
    }
    
    //InsertDevice Methods
    public void insertDevice(Object device){
        boolean fullArray = false;
        for (int i =0; i< devices.length;i++) {
            if (devices[i] == null){
                devices[i] = device; 
                break;}
            //3
            if (i == devices.length - 1){
                fullArray = true;
            }
        }
        //3
        if (fullArray){
            addDevice(device);
        }
    }
    public void insertDevice(String name, double location, boolean switchedOn){
        SmartDevice device = new SmartDevice(name,location,switchedOn);
        insertDevice(device);
    }
    //--------
    
    //GetDevice Methods
    public Object getDevice(int index){
        if (index >= devices.length || index < 0){
            return null;
        }
        else{
            return devices[index];
        }
    }
    public Object getDevice(double location){
        
        for (Object i : devices) {

            SmartDevice device = SmartDevice.class.cast(i);
            if(device.getLocation() == location)
            {
                return device;
            }

        }
        return null;
    }
    //--------
    
    public void toggle(double location){
        SmartDevice device = SmartDevice.class.cast(getDevice(location));
        if(device.isSwitchedOn()){device.switchOff();}
        else{device.switchOn();}
    }
    
    @Override
    public String toString(){
        String result = "";
        for(Object i : devices){
            SmartDevice device = SmartDevice.class.cast(i);
            result = result.concat(device.toString()) + "\n";
        }
        return result;
    }
    
    
    //STEP 3
    
    public void addDevice(Object device){
        Object[] devicesArray = new Object[devices.length + 1];
        System.arraycopy(devices, 0, devicesArray, 0, devices.length);
        devicesArray[devices.length] = device;
        devices = devicesArray;
    }
    
    public void setAllInRoom(int room, boolean status){
        for(Object i : devices){
            SmartDevice device = SmartDevice.class.cast(i);
            if ((int)device.getLocation() == room){
                
                if(!status){
                    device.switchOff();
                }
                
                else if (status){
                    device.switchOn();
                }
            }
        }
    }
    
    public void shutdown(){
        for(Object i : devices){
            SmartDevice device = SmartDevice.class.cast(i);
            device.switchOff();
        }
    }
}
