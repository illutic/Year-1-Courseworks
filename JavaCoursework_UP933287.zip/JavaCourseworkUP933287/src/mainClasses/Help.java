/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainClasses;

import Devices.LightModes;
import Devices.SmartDevice;
import Devices.SmartFridge;
import Devices.SmartLamp;
import java.util.Scanner;

/**
 *
 * @author georg
 */
public class Help {
    public static int inputINT(String outputText){
        System.out.println(outputText);
        Scanner input = new Scanner(System.in);
        return input.nextInt();
    }
    public static String inputSTR(String outputText){
        System.out.println(outputText);
        Scanner input = new Scanner(System.in);
        return input.next();
    }
    public static double inputDOUBLE(String outputText){
        System.out.println(outputText);
        Scanner input = new Scanner(System.in);
        return input.nextDouble();
    }
    public static boolean inputBOOL(String outputText){
        System.out.println(outputText);
        Scanner input = new Scanner(System.in);
        return input.nextBoolean();
    }
    public static void output(String... outputStr){
        for (String i : outputStr){
            System.out.print(i);
        }
        
    }
    
    public static SmartHome createSH(){
        int size = inputINT("Enter an Array Size: ");
        SmartHome sh = new SmartHome(size);
        for (int i = 0; i < size; i++){
            String name = inputSTR("Please enter device " + i + " name: ");
            double location = inputDOUBLE("Please enter "+name+"'s location: ");
            boolean switchedOn = inputBOOL("Please enter "+name+"'s status: ");
            sh.insertDevice(name,location,switchedOn);
        }
        return sh;
    }
    
    public static Object[] populateArray(){
        int size = Help.inputINT("Enter an Array Size: ");
        Object[] dvcs = new Object[size];
        for (int i = 0; i < size; i++){
            String name = Help.inputSTR("Please enter device " + i + " name: ");
            double location = Help.inputDOUBLE("Please enter "+name+"'s location: ");
            boolean switchedOn = Help.inputBOOL("Please enter "+name+"'s status: ");
            dvcs[i] = new SmartDevice(name,location,switchedOn);
        }
        return dvcs;
    }
    
    public static Object[] populateArray4(){
        int size = inputINT("Enter an Array Size: ");
        Object[] dvcs = new Object[size];
        for (int i = 0; i < size; i++){
            String name = inputSTR("Please enter device " + i + " name: ");
            double location = inputDOUBLE("Please enter "+name+"'s location: ");
            if (i%2 == 0){
                boolean switchedOn = inputBOOL("Please enter "+name+"'s status: ");
                dvcs[i] = new SmartDevice(name,location,switchedOn);
            }
            else{
                double temperature = inputDOUBLE("please enter "+ name + "'s Temperature: ");
                dvcs[i] = new SmartFridge(name,location,temperature);
            }
            
        }
        return dvcs;
    }
    
    public static SmartHome createSH4(){
        int size = inputINT("Enter an Array Size: ");
        SmartHome sh = new SmartHome(size);
        for (int i = 0; i < size; i++){
            String name = inputSTR("Please enter device " + i + " name: ");
            double location = inputDOUBLE("Please enter "+name+"'s location: ");
            if(i%2 ==0){
                boolean switchedOn = inputBOOL("Please enter "+name+"'s status: ");
                sh.insertDevice(name,location,switchedOn);
            }
            else{
                double temperature = inputDOUBLE("please enter "+ name + "'s Temperature: ");
                sh.insertDevice(new SmartFridge(name,location,temperature));
            }
            
        }
        return sh;
    }

    public static Object deviceInput(){
        String name = Help.inputSTR("Please enter device name: ");
        double location = Help.inputDOUBLE("Please enter "+name+"'s location: ");
        boolean switchedOn = Help.inputBOOL("Please enter "+name+"'s status: ");
        return new SmartDevice(name,location,switchedOn);
    }
    
    public static Object[] populateArray5(){
        Object[] dvcs = new Object[5];
        dvcs[0]=new SmartFridge("dev1",1.0,50);
        dvcs[1]=new SmartFridge("dev2",2.0,24.1);
        dvcs[2]=new SmartDevice("dev3",1.5,true);
        dvcs[3]=new SmartLamp("dev4",1.2,true,LightModes.SOFT);
        dvcs[4]=new SmartLamp("dev5",2.1,true,LightModes.STANDARD);
        return dvcs;
    }
    
    public static void changeMode(Object tempDevice){
        if(tempDevice.getClass() == SmartLamp.class)
            {
                SmartLamp device = SmartLamp.class.cast(tempDevice);
                int controller = Help.inputINT("Enter: 0 for Night |"
                        + " 1 for Soft |"
                        + " 2 for Standard |"
                        + " 3 for Bright: ");
                switch(controller){
                    case 0: 
                        device.setMode(LightModes.NIGHT);
                        Help.output(device.toString());
                        break;
                    case 1: 
                        device.setMode(LightModes.SOFT);
                        Help.output(device.toString());
                        break;
                    case 2: 
                        device.setMode(LightModes.STANDARD);
                        Help.output(device.toString());
                        break;
                    //case 3: device.setMode(LightModes.BRIGHT);break;
                    default: break;
                }
                
            }
        
    }
    
}
